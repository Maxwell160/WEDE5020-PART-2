# Maxwell Plant Hire Ltd (Pty) - Website Portfolio
## Module: WEDE5020 - Web Development (POE)
**Student Number:** ST10501228  
**Academic Year:** 2026  

---

## Part 1: Project Overview & Design Proposal

### 1. Organisation Overview
* **Company Name:** Maxwell Plant Hire Ltd (Pty)
* **Brief History:** Maxwell Plant Hire Ltd (Pty) is a South African-based company specializing in the rental of construction and industrial equipment. Established to support the growing demand in the construction, mining, and infrastructure sectors, the company has built a reputation for reliability, affordability, and quality service. Over time, it has expanded its fleet and service offerings to cater to both small contractors and large-scale enterprises.
* **Mission Statement:** To provide high-quality, reliable, and affordable plant hire solutions that empower our clients to complete projects efficiently and safely.
* **Vision Statement:** To become a leading plant hire company in Southern Africa, recognized for innovation, customer satisfaction, and operational excellence.
* **Target Audience:** * Construction companies
  * Independent contractors
  * Mining companies
  * Government infrastructure projects
  * DIY builders and small businesses

### 2. Website Goals and Objectives
* **Core Goals:**
  * Increase online visibility and brand awareness.
  * Generate qualified leads and customer inquiries.
  * Showcase available equipment and services.
  * Provide easy access to contact and quotation requests.
  * Build credibility and trust with potential clients.
* **Key Performance Indicators (KPIs):**
  * Website traffic (monthly visitors)
  * Conversion rate (inquiries or quote requests)
  * Bounce rate and Average session duration
  * Number of completed contact forms
  * Search engine ranking (SEO performance)

### 3. Technical Requirements
* **Domain:** `www.maxwellplanthire.co.za`
* **Hosting:** Shared or cloud hosting (e.g., Afrihost, Hostinger)
* **Technologies Used:** HTML5, CSS3
* **Security & Infrastructure:** SSL Certificate setup, basic SEO structure, and a planned content management layout.
* **Equipment Rental & Pricing Structure:**
  * **Grader:** R2,000 / hour
  * **Haul Truck:** R5,500 / hour
  * **Excavator:** R3,000 / hour
  * **Front Loader:** R2,000 / hour

---

## Part 2: Project Upgrade & Changelog

This section outlines the progressive improvements, technical refinements, and structural modifications made when transitioning the website from the Part 1 baseline submission to the Part 2 final deployment.

### Changelog
* **Homepage Enhancements:** The structural layout of `home.html` was updated to incorporate a clean, center-aligned aesthetic for the corporate identity elements. A dynamic slider/marquee component was added to elegantly space out the high-quality machinery assets across the web page.
* **Navigation Bar Fixes:** Resolved positioning issues on the global navigation header. The navigation menu links are now fixed and anchored precisely to the far right of the header section, aligning with modern UI design conventions.
* **Footer Standardisation:** Re-architected the `<footer>` element across all pages. The footer is now explicitly centered at the absolute bottom of each viewport and includes the correct copyright symbols, the updated student number tracking ID, and the current calendar year (2026).
* **Typography & Content Hierarchy:** Upgraded paragraph (`<p>`) tags across all body documents to enhance readability and clarity. Re-organized headings (`<h1>`, `<h2>`, `<h3>`) systematically on the News page for streamlined navigation and logical document flow.
* **About Page Overhaul:** Completely modified and updated the corporate information blocks on `about.html`. Line break (`<br>`) configurations were introduced to ensure proper textual breathing space, producing a seamless, distraction-free user interaction.
* **News & Industry Updates Expansion:** Spaced out information chunks utilizing structured list elements, clean horizontal breaks (`<hr>`), and optimized header hierarchies. Additionally, embedded an external hyperlink connecting directly to an authoritative international logistics news article regarding heavy equipment equipment rentals in South Africa.
* **Contact Page & Location Services Enrichment:** Amplified customer experience on `contact.html` by adding dedicated paragraph headers, customer email endpoints (`inquiries@maxwellplanthire.co.za`), operational hour breakdowns, and an interactive Google Maps location placeholder. The map is seamlessly embedded via an HTML `<iframe>` source element, allowing prospective logistics clients to locate physical corporate offices easily.
* **Styling Strategy (CSS Integration):** Planned and structured architectural styling sheets within `CSS/style.css` to build an appealing visual identity, establish clean grid alignments for machinery displays, manage whitespace, and optimize navigation across multiple form-factor media blocks.

---

## Responsive Interface Presentations

Below are the interface configurations demonstrating how the layout wraps across diverse client viewports. All reference screenshot media assets are located inside the local project workspace under the `images2/` directory tree.

### 1. Desktop Interface Layout
*Optimized for wide-aspect presentation displays and full-scale navigation workflows.*
![Desktop Interface View](images2/desktop.png)

### 2. Tablet Interface Layout
*Optimized for mid-tier viewpoints, displaying scaled fluid-grid element dimensions.*
![Tablet Interface View](images2/tablet.png)

### 3. Mobile Interface Layout
*Optimized for narrow vertical aspect viewports, shifting navigation structures for single-column readability.*
![Mobile Interface View](images2/mobile.png)

---

## References (Harvard Anglia Style)

* Canva, 2026. *Graphic design tool and asset generator*. [online] Available at: <https://www.canva.com> [Accessed 29 May 2026].
* Microsoft, 2026. *Visual Studio Code*. Version 1.90. [software] Redmond, WA: Microsoft Corporation. Available at: <https://code.visualstudio.com> [Accessed 29 May 2026].
* W3Schools, 2026. *HTML & CSS web development tutorials*. [online] Available at: <https://www.w3schools.com> [Accessed 29 May 2026].